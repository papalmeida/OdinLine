# Paprodutos

Aplicação web desenvolvida como exercício avaliativo da disciplina **Desenvolvimento de Sistemas** do curso de **Engenharia de Computação** do CEFET-MG – Unidade Timóteo.

Este sistema complementa a plataforma [OdinLine](https://api-odinline.odiloncorrea.com), permitindo que usuários monitorem o preço de produtos variado registradas em seus catálogos, recebam notificações ou realizem compras automaticamente quando o valor desejado for atingido.

🔗 **Acesse o site publicado:**  
[https://paprodutos.netlify.app/](https://paprodutos.netlify.app/)

---

**Login no Price Alert Crypto:**

- **Usuário:** `p3dr1nh0`  
- **Senha:** `@pedro123`
